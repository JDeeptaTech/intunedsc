# GenerateConfigurationFiles.ps1

param (
    [Parameter(Mandatory = $true)]
    [ValidateSet("Test", "Production", "Staging", "Development")]
    [string]$EnvironmentName,

    [Parameter(Mandatory = $true)]
    [string]$TenantId,

    [Parameter(Mandatory = $true)]
    [string]$AdminUserName,

    [Parameter(Mandatory = $true)]
    [SecureString]$AdminPassword,

    [Parameter(Mandatory = $true)]
    [string]$Domain
)

$basePath = Join-Path -Path $PSScriptRoot -ChildPath "Environments"

# Create environment folder if it doesn't exist
$envPath = Join-Path -Path $basePath -ChildPath $EnvironmentName
if (-not (Test-Path -Path $envPath)) {
    New-Item -Path $envPath -ItemType Directory
}

# Create config folder
$configPath = Join-Path -Path $envPath -ChildPath "Configs"
if (-not (Test-Path -Path $configPath)) {
    New-Item -Path $configPath -ItemType Directory
}

# Generate psd1 (Config Data) file
$psd1Content = @"
@{
    AllNodes = @(
        @{
            NodeName = "localhost"
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
            AdminUserName = "$AdminUserName"
            AdminPassword = (ConvertTo-SecureString "$AdminPassword" -AsPlainText -Force)
        }
    )

    EnvironmentSettings = @{
        EnvironmentName = "$EnvironmentName"
        TenantId = "$TenantId"
        Domain = "$Domain"
        CountryCode = "HK"
    }
}
"@

$psd1File = Join-Path -Path $configPath -ChildPath "M365$($EnvironmentName)Config.psd1"
$psd1Content | Out-File -FilePath $psd1File -Encoding UTF8

# Generate ps1 (Configuration Script) file
$ps1Content = @"
Configuration M365$($EnvironmentName)Configuration {
    param (
        [Parameter(Mandatory = $true)]
        [PSCredential]`$AdminCredential,
        [Parameter(Mandatory = $true)]
        [String]`$TenantId
    )

    Import-DscResource -ModuleName "Microsoft365DSC"

    # Example DSC Resources for $($EnvironmentName) environment
    TeamsTeam {
        Ensure = 'Present'
        DisplayName = '$($EnvironmentName) Team'
        Description = 'A team for the $($EnvironmentName) environment'
        Credential = `$AdminCredential
    }

    SharePointOnlineSite {
        Ensure = 'Present'
        Url = 'https://$($Domain)/sites/$($EnvironmentName)team'
        Owner = '$($AdminUserName)@$($Domain)'
        Credential = `$AdminCredential
    }
}

# Configuration data is passed in when invoked
"@

$ps1File = Join-Path -Path $configPath -ChildPath "M365$($EnvironmentName)Configuration.ps1"
$ps1Content | Out-File -FilePath $ps1File -Encoding UTF8

Write-Host "Configuration files for $($EnvironmentName) environment generated successfully!"
