# Import the necessary modules
Import-Module Microsoft365DSC

# Function to generate MOF files for a given configuration
function Generate-MofFile {
    param (
        [string]$ConfigurationName,
        [string]$ConfigurationPath,
        [string]$ConfigDataPath
    )

    # Import the configuration data
    $ConfigData = Import-PowerShellDataFile -Path $ConfigDataPath

    # Import the configuration script
    . $ConfigurationPath

    # Invoke the configuration to generate the MOF files
    & $ConfigurationName -ConfigurationData $ConfigData -OutputPath "./MOF/$ConfigurationName"
}

# Generate MOF files for Global configuration
Generate-MofFile -ConfigurationName "GlobalDscConfiguration" `
                 -ConfigurationPath "Global/Configurations/GlobalDscConfiguration.ps1" `
                 -ConfigDataPath "Global/CommonConfig/GlobalSettings.psd1"

# Generate MOF files for Test environment
Generate-MofFile -ConfigurationName "M365TestConfiguration" `
                 -ConfigurationPath "Environments/Test/Configs/M365TestConfiguration.ps1" `
                 -ConfigDataPath "Environments/Test/Configs/M365TestConfig.psd1"

# Generate MOF files for Production environment
Generate-MofFile -ConfigurationName "M365ProductionConfiguration" `
                 -ConfigurationPath "Environments/Production/Configs/M365ProductionConfiguration.ps1" `
                 -ConfigDataPath "Environments/Production/Configs/M365ProductionConfig.psd1"

Write-Output "MOF files generation completed."