# Import the necessary modules
Import-Module Microsoft365DSC

# Function to generate MOF files for a given configuration
function New-MofFile {
    param (
        [string]$ConfigurationName,
        [string]$ConfigurationPath,
        [string]$ConfigDataPath
    )

    Write-Host "Generating MOF files for $ConfigurationName configuration,`n" `
        "using configuration script $ConfigurationPath`n" `
        "and configuration data $ConfigDataPath" -ForegroundColor Green

    # Import the configuration data
    $ConfigData = Import-PowerShellDataFile -Path $ConfigDataPath

    # # Extract credentials from ConfigurationData
    # $ApplicationID = $ConfigData.AllNodes[0].ApplicationID
    # $ApplicationSecret = $ConfigData.AllNodes[0].ApplicationSecret
    # $TenantID = $ConfigData.AllNodes[0].TenantID

    # # Convert the ApplicationSecret to a secure string
    # $SecureApplicationSecret = ConvertTo-SecureString -String $ApplicationSecret -AsPlainText -Force

    # # Create a PSCredential object for the Tenant Admin
    # $AppCredentials = New-Object System.Management.Automation.PSCredential ('ApplicationSecret', $SecureApplicationSecret);
    # # New-Object -TypeName PSCredential -ArgumentList ($ApplicationID, $SecureApplicationSecret)


    # Import the configuration script
    . $ConfigurationPath

    # Invoke the configuration to generate the MOF files
    & $ConfigurationName -ApplicationID $ConfigData.GlobalSettings.ApplicationID `
        -CertificateThumbprint $ConfigData.GlobalSettings.CertificateThumbprint `
        -TenantId $ConfigData.GlobalSettings.TenantId `
        -ConfigurationData $ConfigData -OutputPath "./MOF/$ConfigurationName" -Verbose
}

# Generate MOF files for Global configuration
New-MofFile -ConfigurationName "GlobalDscConfiguration" `
    -ConfigurationPath "Global/Configurations/GlobalDscConfiguration.ps1" `
    -ConfigDataPath "Global/CommonConfig/GlobalSettings.psd1"

# # Generate MOF files for Test environment
# New-MofFile -ConfigurationName "M365TestConfiguration" `
#                  -ConfigurationPath "Environments/Test/Configs/M365TestConfiguration.ps1" `
#                  -ConfigDataPath "Environments/Test/Configs/M365TestConfig.psd1"

# # Generate MOF files for Production environment
# Generate-MofFile -ConfigurationName "M365ProductionConfiguration" `
#                  -ConfigurationPath "Environments/Production/Configs/M365ProductionConfiguration.ps1" `
#                  -ConfigDataPath "Environments/Production/Configs/M365ProductionConfig.psd1"

Write-Output "MOF files generation completed."