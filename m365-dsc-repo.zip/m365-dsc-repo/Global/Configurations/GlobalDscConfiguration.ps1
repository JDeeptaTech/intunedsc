Configuration GlobalDscConfiguration {
    param (
        [Parameter(Mandatory = $True)]
        [System.String]$ApplicationID,
        [Parameter(Mandatory = $True)]
        [System.String]$CertificateThumbprint,
        [Parameter(Mandatory = $True)]
        [System.String]$TenantId
    )

    Import-DscResource -ModuleName "Microsoft365DSC"

    IntuneDeviceCompliancePolicyAndroid "IntuneDeviceCompliancePolicyAndroid" {
        Ensure                                             = 'Present'
        DisplayName                                        = 'Test Android Compliance Policy'
        Description                                        = 'Compliance policy for Android devices in the Test environment'
        PasswordRequired                                   = $true
        PasswordMinimumLength                              = 6
        PasswordRequiredType                               = 'Alphanumeric'
        PasswordExpirationDays                             = 90
        PasswordMinutesOfInactivityBeforeLock              = 5
        PasswordPreviousPasswordBlockCount                 = 5
        OsMinimumVersion                                   = '6.0'
        OsMaximumVersion                                   = '11.0'
        SecurityPreventInstallAppsFromUnknownSources       = $true
        SecurityDisableUsbDebugging                        = $true
        SecurityRequireVerifyApps                          = $true
        SecurityRequireSafetyNetAttestationBasicIntegrity  = $true
        SecurityRequireSafetyNetAttestationCertifiedDevice = $true
        SecurityRequireGooglePlayServices                  = $true
        SecurityRequireUpToDateSecurityProviders           = $true
        SecurityRequireCompanyPortalAppIntegrity           = $true
        ApplicationId                                      = $ApplicationID
        CertificateThumbprint                              = $CertificateThumbprint
        TenantId                                           = $TenantId
    }
}
